const express = require('express')
const Route = express.Router()
const multer = require('multer')
const storage = multer.memoryStorage()
const upload = multer({ storage: storage})

//
// const PicStorage = multer.memoryStorage()
// const PicUpload = multer({ storage: PicStorage})
//
const AuthController = require('./Controllers/AdminController')
const DB = require('./Config/ConnectDB')
DB()

// Auth
Route.post('/user/register', AuthController.Register)
Route.post('/user/login', AuthController.Login)

// Route.post('/admin/add-movie', upload.single('video'), PicUpload.single('thumbnail'), AuthController.AddMovie)
Route.post('/admin/add-movie', upload.fields([ { name: 'video', maxCount: 1 }, { name: 'thumbnail', maxCount: 1 } ]), AuthController.AddMovie);
Route.post('/admin/events', AuthController.Events)


module.exports = Route
